// Password protection
function checkPassword() {
  const input = document.getElementById("password-input").value;
  if (input === "Nickytech") {
    document.getElementById("password-screen").classList.add("hidden");
    document.getElementById("app").classList.remove("hidden");
  } else {
    document.getElementById("error").innerText = "❌ Wrong password!";
  }
}

// Dark/Light mode toggle
const modeToggle = document.getElementById("mode-toggle");
modeToggle?.addEventListener("click", () => {
  document.body.classList.toggle("light");
  modeToggle.innerText = document.body.classList.contains("light")
    ? "☀️ Light Mode"
    : "🌙 Dark Mode";
});

// Download code as file
function downloadCode() {
  const code = document.getElementById("codeInput").value;
  if (!code.trim()) {
    alert("⚠️ Please enter some code first!");
    return;
  }
  const blob = new Blob([code], { type: "text/plain" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "sourcecode.txt";
  link.click();
}